import { useState } from "react";
import { supabase } from "../services/supabaseClient";

function useDistrictsAndZones() {
  const [districts, setDistricts] = useState([]);
  const [zones, setZones] = useState([]);
  const [selectedDistrict, setSelectedDistrict] = useState(null);

  const fetchDistricts = async () => {
    try {
      const { data, error } = await supabase.from("districts").select("*");
      if (error) {
        console.error("Error fetching districts:", error);
        return;
      }
      setDistricts(data || []);
    } catch (err) {
      console.error("Error fetching districts:", err);
    }
  };

  const fetchZones = async (districtName) => {
    try {
      const { data, error } = await supabase
        .from("zones")
        .select("*")
        .like("district_name", `${districtName}%`);
      if (error) {
        console.error("Error fetching zones:", error);
        return;
      }
      setZones(data || []);
    } catch (err) {
      console.error("Error fetching zones:", err);
    }
  };

  const clearZonesAndSelection = () => {
    setSelectedDistrict(null);
    setZones([]);
  };

  return {
    districts,
    zones,
    selectedDistrict,
    setSelectedDistrict,
    fetchDistricts,
    fetchZones,
    clearZonesAndSelection,
  };
}

export default useDistrictsAndZones;