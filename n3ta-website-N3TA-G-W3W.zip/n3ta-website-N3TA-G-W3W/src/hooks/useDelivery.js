// import { useState } from "react";

// function useDelivery(zones) {
//   const [startZone, setStartZone] = useState(null);
//   const [endZone, setEndZone] = useState(null);
//   const [route, setRoute] = useState([]);
//   const [driverPosition, setDriverPosition] = useState(null);
//   const [deliveryId, setDeliveryId] = useState(null);
//   const [deliveryStatus, setDeliveryStatus] = useState(null);

//   const requestDelivery = async () => {
//     if (!startZone || !endZone) {
//       alert("Please select both start and end zones.");
//       return;
//     }

//     try {
//       setDeliveryStatus("pending");
//       setDeliveryId("DEL-" + Math.random().toString(36).substr(2, 9));
//       setDriverPosition(startZone.coordinates);
//       setDeliveryStatus("in_progress");
//     } catch (error) {
//       console.error("Error requesting delivery:", error);
//       setDeliveryStatus("failed");
//     }
//   };

//   const selectRandomStartZone = (excludeZoneName) => {
//     const availableZones = zones.filter(
//       (zone) => zone.name !== excludeZoneName && zone.coordinates
//     );
//     if (availableZones.length === 0) {
//       alert("No available zones to select as start zone.");
//       return;
//     }
//     const randomIndex = Math.floor(Math.random() * availableZones.length);
//     const randomZone = availableZones[randomIndex];
//     setStartZone({
//       name: randomZone.name,
//       coordinates: randomZone.coordinates,
//     });
//   };

//   const calculateRoute = () => {
//     if (!startZone || !endZone) {
//       alert("Please select both start and end zones to show navigation.");
//       return;
//     }

//     // Simulate a route between startZone and endZone coordinates
//     // In a real app, this would use a routing API (e.g., OSRM, Google Maps Directions API)
//     const routeCoordinates = [
//       startZone.coordinates,
//       // Add intermediate points if needed (simplified for now)
//       endZone.coordinates,
//     ];

//     setRoute(routeCoordinates);
//   };

//   return {
//     startZone,
//     setStartZone,
//     endZone,
//     setEndZone,
//     route,
//     driverPosition,
//     deliveryId,
//     deliveryStatus,
//     requestDelivery,
//     selectRandomStartZone,
//     calculateRoute,
//   };
// }

// export default useDelivery;

import { useState } from "react";

function useDelivery(zones) {
  const [startZone, setStartZone] = useState(null);
  const [endZone, setEndZone] = useState(null);
  const [route, setRoute] = useState([]);
  const [driverPosition, setDriverPosition] = useState(null);
  const [deliveryId, setDeliveryId] = useState(null);
  const [deliveryStatus, setDeliveryStatus] = useState(null);

  const requestDelivery = async () => {
    if (!startZone || !endZone) {
      alert("Please select both start and end zones.");
      return;
    }

    try {
      setDeliveryStatus("pending");
      setDeliveryId("DEL-" + Math.random().toString(36).substr(2, 9));
      setDriverPosition(startZone.coordinates);
      setDeliveryStatus("in_progress");
    } catch (error) {
      console.error("Error requesting delivery:", error);
      setDeliveryStatus("failed");
    }
  };

  const selectRandomStartZone = (excludeZoneName) => {
    const availableZones = zones.filter(
      (zone) => zone.name !== excludeZoneName && zone.coordinates
    );
    if (availableZones.length === 0) {
      alert(
        `No available zones to select as start zone. Total zones: ${zones.length}, Excluded zone: ${
          excludeZoneName || "None"
        }, Zones with coordinates: ${
          zones.filter((zone) => zone.coordinates).length
        }`
      );
      return null;
    }
    const randomIndex = Math.floor(Math.random() * availableZones.length);
    const randomZone = availableZones[randomIndex];
    setStartZone({
      name: randomZone.name,
      coordinates: randomZone.coordinates,
    });
    return { name: randomZone.name, coordinates: randomZone.coordinates };
  };

  const calculateRoute = () => {
    if (!startZone || !endZone) {
      alert("Please select both start and end zones to show navigation.");
      return;
    }

    console.log("Start Zone in calculateRoute:", startZone);
    console.log("End Zone in calculateRoute:", endZone);

    const routeCoordinates = [
      startZone.coordinates,
      endZone.coordinates,
    ];

    console.log("Route Coordinates in calculateRoute:", routeCoordinates);

    setRoute(routeCoordinates);
  };

  return {
    startZone,
    setStartZone,
    endZone,
    setEndZone,
    route,
    driverPosition,
    deliveryId,
    deliveryStatus,
    requestDelivery,
    selectRandomStartZone,
    calculateRoute,
  };
}

export default useDelivery;