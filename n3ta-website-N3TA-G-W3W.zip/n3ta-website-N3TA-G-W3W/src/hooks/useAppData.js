import { useState, useEffect } from "react";
import { supabase } from "../services/supabaseClient";
import { convertGeoJSONToLatLng } from "../utils/mapUtils";

function useAppData() {
  const [districts, setDistricts] = useState([]);
  const [zones, setZones] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const districtDisplayNames = {
    "TRP-00": "Old City",
    "TRP-01": "New Tripoli",
    "TRP-02": "Mansoura",
    "TRP-03": "Bab bin Ghashir",
    "TRP-04": "Ben Ashour",
    "TRP-05": "Zawit E Dahmani + Dhahra",
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        const { data: districtsData, error: districtsError } = await supabase
          .from("districts")
          .select("*");
        if (districtsError) {
          console.error("Districts fetch error:", districtsError);
          throw new Error(`Failed to fetch districts: ${districtsError.message}`);
        }

        const { data: zonesData, error: zonesError } = await supabase
          .from("zones")
          .select("*");
        if (zonesError) {
          console.error("Zones fetch error:", zonesError);
          throw new Error(`Failed to fetch zones: ${zonesError.message}`);
        }

        setDistricts(Array.isArray(districtsData) ? districtsData : []);
        setZones(Array.isArray(zonesData) ? zonesData : []);
      } catch (err) {
        console.error("Fetch data error:", err);
        setError(`Error loading data: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const validDistricts = districts.filter((district) => {
    const positions = convertGeoJSONToLatLng(district.geometry, district.name);
    return positions.length > 0;
  });

  const validZones = zones.filter((zone) => {
    const positions = convertGeoJSONToLatLng(zone.geometry, zone.name);
    return positions.length > 0;
  });

  const filteredDistricts = validDistricts.filter(
    (district) =>
      district.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (districtDisplayNames[district.name] || "")
        .toLowerCase()
        .includes(searchQuery.toLowerCase())
  );

  const filteredZones = validZones.filter(
    (zone) =>
      zone.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      zone.district_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (districtDisplayNames[zone.district_name] || "")
        .toLowerCase()
        .includes(searchQuery.toLowerCase())
  );

  return {
    districts,
    zones,
    searchQuery,
    setSearchQuery,
    loading,
    error,
    filteredDistricts,
    filteredZones,
    validZones,
    districtDisplayNames,
  };
}

export default useAppData;

// import { useState, useEffect } from "react";
// import { supabase } from "../services/supabaseClient";
// import { getCentroid } from "../utils/mapUtils";

// function useAppData() {
//   const [districts, setDistricts] = useState([]);
//   const [zones, setZones] = useState([]);
//   const [searchQuery, setSearchQuery] = useState("");
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [filteredDistricts, setFilteredDistricts] = useState([]);
//   const [filteredZones, setFilteredZones] = useState([]);
//   const [validZones, setValidZones] = useState([]);
//   const [districtDisplayNames, setDistrictDisplayNames] = useState({});

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         // Fetch districts
//         const { data: districtsData, error: districtsError } = await supabase
//           .from("districts")
//           .select("*");
//         if (districtsError) throw districtsError;

//         // Fetch zones
//         const { data: zonesData, error: zonesError } = await supabase
//           .from("zones")
//           .select("*");
//         if (zonesError) throw zonesError;

//         // Add coordinates to zones by calculating the centroid of their geometry
//         const zonesWithCoordinates = zonesData.map((zone) => {
//           const centroid = getCentroid(zone.geometry);
//           return {
//             ...zone,
//             coordinates: centroid || [32.8872, 13.1913], // Fallback to map center
//           };
//         });

//         // Process district display names
//         const displayNames = districtsData.reduce((acc, district) => {
//           acc[district.name] = district.display_name || district.name;
//           return acc;
//         }, {});

//         setDistricts(districtsData);
//         setZones(zonesWithCoordinates);
//         setFilteredDistricts(districtsData);
//         setFilteredZones(zonesWithCoordinates);
//         setValidZones(zonesWithCoordinates.filter((zone) => zone.coordinates));
//         setDistrictDisplayNames(displayNames);
//       } catch (err) {
//         setError("Failed to load data. Please try again later.");
//         console.error("Error fetching data:", err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, []);

//   return {
//     districts,
//     zones,
//     searchQuery,
//     setSearchQuery,
//     loading,
//     error,
//     filteredDistricts,
//     filteredZones,
//     validZones,
//     districtDisplayNames,
//   };
// }

// export default useAppData;