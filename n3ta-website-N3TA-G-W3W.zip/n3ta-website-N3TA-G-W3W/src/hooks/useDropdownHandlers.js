import { useState, useEffect, useRef } from "react";

function useDropdownHandlers({
  setSearchQuery,
  fetchDistricts,
  fetchZones,
  setSelectedDistrict,
  clearZonesAndSelection,
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  const handleFocus = () => {
    setIsDropdownOpen(true);
    fetchDistricts();
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleDistrictSelect = async (district) => {
    setSelectedDistrict(district);
    setSearchQuery(district.name);
    console.log(`Fetching zones for district: ${district.name}`);
    const fetchedZones = await fetchZones(district.name);
    console.log(`Zones fetched for ${district.name}:`, fetchedZones);
  };

  const handleZoneSelect = (zone) => {
    setSearchQuery(zone.name);
    setIsDropdownOpen(false);
  };

  const handleInputChange = (e) => {
    setSearchQuery(e.target.value);
    if (!e.target.value) {
      clearZonesAndSelection();
    }
  };

  return {
    isDropdownOpen,
    dropdownRef,
    handleFocus,
    handleDistrictSelect,
    handleZoneSelect,
    handleInputChange,
  };
}

export default useDropdownHandlers;