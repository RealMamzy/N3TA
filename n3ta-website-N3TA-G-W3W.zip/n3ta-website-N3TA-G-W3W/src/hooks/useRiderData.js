import { useState, useEffect } from "react";
import { supabase } from "../services/supabaseClient";
import { convertGeoJSONToLatLng } from "../utils/mapUtils";

function useRiderData() {
  const [districts, setDistricts] = useState([]);
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const districtDisplayNames = {
    "TRP-00": "Old City",
    "TRP-01": "New Tripoli",
    "TRP-02": "Mansoura",
    "TRP-03": "Bab bin Ghashir",
    "TRP-04": "Ben Ashour",
    "TRP-05": "Zawit E Dahmani + Dhahra",
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError("");

        const { data: districtsData, error: districtsError } = await supabase
          .from("districts")
          .select("*");
        if (districtsError) {
          console.error("Districts fetch error:", districtsError);
          throw new Error(`Failed to fetch districts: ${districtsError.message}`);
        }

        const { data: zonesData, error: zonesError } = await supabase
          .from("zones")
          .select("*");
        if (zonesError) {
          console.error("Zones fetch error:", zonesError);
          throw new Error(`Failed to fetch zones: ${zonesError.message}`);
        }

        setDistricts(Array.isArray(districtsData) ? districtsData : []);
        setZones(Array.isArray(zonesData) ? zonesData : []);
      } catch (err) {
        console.error("Fetch data error:", err);
        setError(`Error loading data: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const validDistricts = districts.filter((district) => {
    const positions = convertGeoJSONToLatLng(district.geometry, district.name);
    return positions.length > 0;
  });

  const validZones = zones.filter((zone) => {
    const positions = convertGeoJSONToLatLng(zone.geometry, zone.name);
    return positions.length > 0;
  });

  return {
    districts,
    zones,
    validDistricts,
    validZones,
    loading,
    error,
    districtDisplayNames,
  };
}

export default useRiderData;