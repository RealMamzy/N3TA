import * as turf from '@turf/turf';

export const convertGeoJSONToLatLng = (geometry, entityName = "unknown") => {
  if (!geometry) return [];

  if (geometry.type === "Polygon") {
    try {
      const positions = geometry.coordinates[0].map(([lng, lat]) => [lat, lng]);
      const uniqueCoords = new Set(
        positions.map((coord) => `${coord[0]},${coord[1]}`)
      );
      if (uniqueCoords.size <= 1) return [];
      return positions;
    } catch (err) {
      return [];
    }
  } else if (geometry.type === "MultiPolygon") {
    try {
      const positions = geometry.coordinates.flatMap((polygon) =>
        polygon[0].map(([lng, lat]) => [lat, lng])
      );
      const uniqueCoords = new Set(
        positions.map((coord) => `${coord[0]},${coord[1]}`)
      );
      if (uniqueCoords.size <= 1) return [];
      return positions;
    } catch (err) {
      return [];
    }
  }
  return [];
};

export const getCentroid = (geometry) => {
  if (!geometry) return null;

  if (geometry.type === "Polygon") {
    const coords = geometry.coordinates[0];
    let latSum = 0;
    let lngSum = 0;
    let count = 0;
    for (const [lng, lat] of coords) {
      latSum += lat;
      lngSum += lng;
      count++;
    }
    return count > 0 ? [latSum / count, lngSum / count] : null;
  } else if (geometry.type === "MultiPolygon") {
    let latSum = 0;
    let lngSum = 0;
    let totalPoints = 0;

    for (const polygon of geometry.coordinates) {
      const coords = polygon[0];
      let polyLatSum = 0;
      let polyLngSum = 0;
      let polyCount = 0;

      for (const [lng, lat] of coords) {
        polyLatSum += lat;
        polyLngSum += lng;
        polyCount++;
      }

      if (polyCount > 0) {
        latSum += polyLatSum / polyCount;
        lngSum += polyLngSum / polyCount;
        totalPoints++;
      }
    }

    return totalPoints > 0 ? [latSum / totalPoints, lngSum / totalPoints] : null;
  }

  return null;
};

export const getDistrictColor = (districtName) => {
  const colors = {
    "TRP-00": "red",
    "TRP-01": "blue",
    "TRP-02": "green",
    "TRP-03": "orange",
    "TRP-04": "purple",
    "TRP-05": "yellow",
    Unknown: "gray",
  };
  return colors[districtName] || "gray";
};

export const getRandomPointInZone = (zone) => {
  const polygon = turf.polygon(zone.geometry.coordinates);
  const bbox = turf.bbox(polygon);
  let point;
  do {
    point = turf.randomPoint(1, { bbox }).features[0];
  } while (!turf.booleanPointInPolygon(point, polygon));
  const [lng, lat] = point.geometry.coordinates;
  return [lat, lng]; // Return [lat, lng] for Leaflet compatibility
};