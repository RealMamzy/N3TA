import React from "react";

function Dropdown({ isOpen, districts, zones, selectedDistrict, onDistrictSelect, onZoneSelect }) {
  if (!isOpen) return null;

  return (
    <ul className="dropdown-list">
      {selectedDistrict ? (
        zones.length > 0 ? (
          zones.map((zone) => (
            <li
              key={zone.name}
              onClick={() => onZoneSelect(zone)}
              className="dropdown-item"
            >
              {zone.name} 
            </li>
          ))
        ) : (
          <li className="dropdown-item">No zones found for this district</li>
        )
      ) : (
        districts.length > 0 ? (
          districts.map((district) => (
            <li
              key={district.name}
              onClick={() => onDistrictSelect(district)}
              className="dropdown-item"
            >
              {district.name}
            </li>
          ))
        ) : (
          <li className="dropdown-item">Loading districts...</li>
        )
      )}
    </ul>
  );
}

export default Dropdown;