import React, { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";

function PopupController({ zones, selectedZone, type, getCentroid }) {
  const map = useMap();
  const popupRef = useRef({});

  useEffect(() => {
    if (!selectedZone) return;

    const zone = zones.find((z) => z.name === selectedZone);
    if (!zone) return;

    const centroid = getCentroid(zone.geometry);
    if (!centroid) return;

    // Close all existing popups
    Object.values(popupRef.current).forEach((popup) => {
      popup.remove();
    });

    // Create and open a new popup
    const popup = L.popup()
      .setLatLng(centroid)
      .setContent(`${type}: ${zone.name}`)
      .openOn(map);

    popupRef.current[selectedZone] = popup;
  }, [selectedZone, zones, type, map, getCentroid]);

  return null;
}

export default PopupController;