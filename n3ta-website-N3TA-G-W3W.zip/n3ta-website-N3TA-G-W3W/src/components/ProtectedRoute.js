import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

function ProtectedRoute({ children, requiredRole }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="text-center mt-10">Loading...</div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (requiredRole && user.role !== requiredRole) {
    return (
      <div className="bg-white min-h-screen">
        <div className="bg-gray-800 text-white text-center py-4">
          Access Denied: You must be a {requiredRole} to view this page.
        </div>
      </div>
    );
  }
  return children;
}

export default ProtectedRoute;