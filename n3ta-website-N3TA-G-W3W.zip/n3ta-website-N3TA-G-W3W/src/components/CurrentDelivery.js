import React from "react";

function CurrentDelivery({ delivery, onStart, onCancel }) {
  const { n3taCode, clientName, note, coords } = delivery;

  return (
    <div className="delivery-info assigned mt-4">
      <h2 className="text-xl font-semibold">New Delivery Assigned:</h2>
      <p>N3TA Code: <strong>{n3taCode}</strong></p>
      <p>Client Name: <strong>{clientName}</strong></p>
      <p>Note: <strong>{note}</strong></p>
      {coords && (
        <p className="text-xs">
          Coords: {coords[0].toFixed(4)}, {coords[1].toFixed(4)}
        </p>
      )}
      <div className="action-buttons">
        <button className="rider-button start-nav-button" onClick={onStart}>
          Start Delivery
        </button>
        <button className="rider-button cancel-button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </div>
  );
}

export default CurrentDelivery;