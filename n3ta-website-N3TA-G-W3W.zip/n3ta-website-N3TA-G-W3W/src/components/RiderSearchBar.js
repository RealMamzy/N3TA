import "../styles/home.css"; // Reuse the styling from home.css

function RiderSearchBar({ onSearch }) {
  return (
    <div className="rider-search-container">
      <input
        type="text"
        className="rider-search-input"
        placeholder="Filter deliveries by zone or status..."
        onChange={(e) => onSearch(e.target.value)}
      />
    </div>
  );
}

export default RiderSearchBar;