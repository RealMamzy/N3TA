import React from "react";

function Footer() {
  return (
    <footer className="footer">
      © 2025 N3TA. All rights reserved.
    </footer>
  );
}

export default Footer;