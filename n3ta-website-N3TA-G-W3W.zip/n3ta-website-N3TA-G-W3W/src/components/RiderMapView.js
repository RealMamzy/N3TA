import React, { useEffect, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, Polygon, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import RoutingMachine from "./RoutingMachine";
import { convertGeoJSONToLatLng, getDistrictColor } from "../utils/mapUtils";
import "../styles/rider.css";

// Truck Marker Icon for Rider
const truckIcon = L.icon({
  iconUrl: "/truck-icon.png", // Replace with the actual path to your hosted image
  iconSize: [25, 25], // Adjusted size for the isometric truck
  iconAnchor: [20, 20], // Center the icon on the map
  popupAnchor: [0, -20], // Position the popup above the icon
  className: "truck-marker",
});

// Destination Marker Icon
const destinationIcon = L.icon({
  iconUrl: "https://img.icons8.com/ios-filled/50/FA5252/marker.png",
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
});

function RiderMapView({ currentLocation, destination, districts, zones, destinationAddressCode, deliveryStatus, onDeliveryComplete }) {
  const defaultCenter = [32.8872, 13.1913];
  const mapRef = useRef(null);
  const [simulatedPosition, setSimulatedPosition] = useState(currentLocation);
  const [routeCoordinates, setRouteCoordinates] = useState([]);
  const [simulationInterval, setSimulationInterval] = useState(null);
  const [mapInstance, setMapInstance] = useState(null);

  // Update simulated position when currentLocation changes (initial position)
  useEffect(() => {
    setSimulatedPosition(currentLocation);
  }, [currentLocation]);

  // Invalidate map size and set map instance on mount
  useEffect(() => {
    if (mapRef.current?.leafletElement) {
      mapRef.current.leafletElement.invalidateSize();
      setMapInstance(mapRef.current.leafletElement);
    }
  }, []);

  // Handle map focusing
  useEffect(() => {
    if (!mapRef.current?.leafletElement) return;

    if (currentLocation && destination) {
      try {
        const bounds = L.latLngBounds([currentLocation, destination]);
        mapRef.current.leafletElement.flyToBounds(bounds, { padding: [50, 50], maxZoom: 16, duration: 1 });
      } catch (e) {
        console.error("FlyToBounds error:", e);
      }
    } else if (currentLocation) {
      try {
        mapRef.current.leafletElement.flyTo(currentLocation, 14, { duration: 1 });
      } catch (e) {
        console.error("FlyTo error:", e);
      }
    }
  }, [currentLocation, destination]);

  // Handle delivery simulation
  useEffect(() => {
    // Clear interval when delivery is not navigating or canceled
    if (deliveryStatus !== "navigating" && simulationInterval) {
      clearInterval(simulationInterval);
      setSimulationInterval(null);
      setRouteCoordinates([]); // Remove route lines
      // Keep truck at current position (no reset to base)
    }

    // Start simulation only when navigating
    if (deliveryStatus === "navigating" && currentLocation && destination) {
      const router = L.Routing.osrmv1();
      router.route(
        [
          L.Routing.waypoint(L.latLng(currentLocation[0], currentLocation[1])),
          L.Routing.waypoint(L.latLng(destination[0], destination[1])),
        ],
        (err, routes) => {
          if (err) {
            console.error("Error generating route:", err);
            return;
          }

          if (routes && routes.length > 0) {
            const coords = routes[0].coordinates.map(coord => ({
              lat: coord.lat,
              lng: coord.lng,
            }));
            setRouteCoordinates(coords);

            let currentStep = 0;
            const totalSteps = coords.length - 1;

            const interval = setInterval(() => {
              currentStep++;
              const progress = currentStep / totalSteps;
              const routeIndex = Math.min(Math.floor(progress * (coords.length - 1)), coords.length - 1);
              const coord = coords[routeIndex];
              if (coord) {
                setSimulatedPosition([coord.lat, coord.lng]);
                if (mapRef.current?.leafletElement) {
                  mapRef.current.leafletElement.panTo([coord.lat, coord.lng], { animate: true });
                }
              }

              if (currentStep >= totalSteps) {
                clearInterval(interval);
                setSimulationInterval(null);
                if (onDeliveryComplete) onDeliveryComplete();
              }
            }, 300);

            setSimulationInterval(interval);
          }
        }
      );
    }

    // Cleanup on unmount or status change
    return () => {
      if (simulationInterval) {
        clearInterval(simulationInterval);
        setSimulationInterval(null);
      }
    };
  }, [deliveryStatus, currentLocation, destination, onDeliveryComplete]);

  const zonesToDisplay = zones ? zones.filter(zone => zone.geometry && convertGeoJSONToLatLng(zone.geometry, zone.name).length > 0) : [];
  const districtsToDisplay = districts ? districts.filter(district => district.geometry && convertGeoJSONToLatLng(district.geometry, district.name).length > 0) : [];

  return (
    <div className="rider-map-container">
      <MapContainer
        ref={mapRef}
        center={defaultCenter}
        zoom={13}
        style={{ height: "100%", width: "100%" }}
        whenCreated={(mapInstance) => {
          mapRef.current = { leafletElement: mapInstance };
          mapInstance.invalidateSize();
          setMapInstance(mapInstance);
        }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {districtsToDisplay.map((district, index) => {
          try {
            const positions = convertGeoJSONToLatLng(district.geometry, district.name);
            if (!positions || positions.length === 0) return null;
            return (
              <Polygon
                key={`district-${district.name}-${index}`}
                positions={positions}
                pathOptions={{
                  color: getDistrictColor(district.name),
                  weight: 2,
                  fillOpacity: 0.05,
                  fillColor: getDistrictColor(district.name),
                }}
              >
                <Popup>District: {district.name}</Popup>
              </Polygon>
            );
          } catch (err) {
            console.error(`Error rendering district ${district.name}:`, err);
            return null;
          }
        })}
        {zonesToDisplay.map((zone, index) => {
          try {
            const positions = convertGeoJSONToLatLng(zone.geometry, zone.name);
            if (!positions || positions.length === 0) return null;
            const isDestinationZone =
              (deliveryStatus === "assigned" || deliveryStatus === "navigating") &&
              destinationAddressCode &&
              zone.name === destinationAddressCode.split("-").slice(0, -1).join("-");
            const isBusinessZone = zone.name === "TRP-03-102A";
            return (
              <Polygon
                key={`zone-${zone.name}-${index}`}
                positions={positions}
                pathOptions={{
                  color: isBusinessZone ? "purple" : getDistrictColor(zone.district_name),
                  weight: isBusinessZone || isDestinationZone ? 3 : 1,
                  fillOpacity: isBusinessZone || isDestinationZone ? 0.5 : 0.2,
                  fillColor: isDestinationZone ? "#ffeb3b" : (isBusinessZone ? "purple" : getDistrictColor(zone.district_name)),
                }}
              >
                <Popup>{isBusinessZone ? "Business Zone: TRP-03-102A" : `Zone: ${zone.name}`}</Popup>
              </Polygon>
            );
          } catch (err) {
            console.error(`Error rendering zone ${zone.name}:`, err);
            return null;
          }
        })}
        {routeCoordinates.length > 0 && (
          <Polyline
            positions={routeCoordinates.map(coord => [coord.lat, coord.lng])}
            color="#ffc107"
            weight={4}
          />
        )}
        {simulatedPosition && (
          <Marker position={simulatedPosition} icon={truckIcon}>
            <Popup>Rider Location</Popup>
          </Marker>
        )}
        {destination && (
          <Marker position={destination} icon={destinationIcon}>
            <Popup>Delivery: <br /> {destinationAddressCode}</Popup>
          </Marker>
        )}
        {/* Render RoutingMachine only when navigating and map is ready */}
        {mapInstance && currentLocation && destination && deliveryStatus === "navigating" && (
          <RoutingMachine
            start={currentLocation}
            end={destination}
            isNavigating={deliveryStatus === "navigating"}
            map={mapInstance}
          />
        )}
      </MapContainer>
    </div>
  );
}

export default RiderMapView;