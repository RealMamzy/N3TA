import React, { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Polygon, Popup, Polyline, Marker, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import MapController from "./MapController.js";
import PopupController from "./PopupController";
import ErrorBoundary from "./ErrorBoundary";
import { getCentroid, getDistrictColor, convertGeoJSONToLatLng } from "../utils/mapUtils";

// Custom marker icons
const simulatedIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/171/171239.png", // Car icon
  iconSize: [30, 30],
  iconAnchor: [15, 15],
  popupAnchor: [0, -15],
  className: "simulated-marker",
});

const doorstepIcon = L.icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/25/25694.png", // House icon
  iconSize: [25, 25],
  iconAnchor: [12, 12],
  popupAnchor: [0, -12],
});

// Component to handle zooming to the selected zone
function ZoomToSelectedZone({ zones, searchQuery, isJourneyActive }) {
  const map = useMap();
  const hasZoomedRef = useRef(null); // Track the last zoomed searchQuery

  useEffect(() => {
    if (!searchQuery || !zones || isJourneyActive) return; // Skip zooming if journey is active or starting

    // Only zoom if the searchQuery has changed and we haven't zoomed to it yet
    if (hasZoomedRef.current === searchQuery) return;

    const selectedZone = zones.find((zone) => zone.name === searchQuery);
    if (!selectedZone) return;

    const positions = convertGeoJSONToLatLng(selectedZone.geometry, selectedZone.name);
    if (!positions || positions.length === 0) return;

    const bounds = L.latLngBounds(positions);
    if (!bounds.isValid()) return;

    map.flyToBounds(bounds, {
      padding: [50, 50],
      maxZoom: 15,
      duration: 1,
    });

    // Update the ref to indicate we've zoomed to this searchQuery
    hasZoomedRef.current = searchQuery;
  }, [searchQuery, zones, map, isJourneyActive]);

  return null;
}

// Component to control map behavior during the journey
function MapBehaviorController({ isJourneyActive }) {
  const map = useMap();

  useEffect(() => {
    // Since we want the user to manually control the map, we won't lock interactions
    // However, we can ensure the map doesn't auto-move by removing any event listeners that might cause it
    if (isJourneyActive) {
      map.removeEventListener('move'); // Remove any move event listeners that might interfere
    }
  }, [isJourneyActive, map]);

  return null;
}

function MapView({
  districts,
  zones,
  startZone,
  endZone,
  route,
  districtDisplayNames,
  searchQuery,
  simulatedLocation,
  selectedPoint,
  onPointSelect,
  isJourneyActive,
}) {
  const mapRef = useRef(null);

  return (
    <ErrorBoundary>
      <div className="map-container">
        <MapContainer
          center={[32.8872, 13.1913]}
          zoom={12}
          style={{ width: "100%", height: "100%" }}
          whenCreated={mapInstance => { mapRef.current = mapInstance; }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          {districts.map((district, index) => {
            const positions = convertGeoJSONToLatLng(district.geometry, district.name);
            return (
              <Polygon
                key={`district-${district.name}-${index}`}
                positions={positions}
                color={getDistrictColor(district.name)}
                weight={3}
                fillOpacity={0.1}
              >
                <Popup>
                  {district.name} -{" "}
                  {districtDisplayNames[district.name] || "Unknown"}
                </Popup>
              </Polygon>
            );
          })}
          {zones.map((zone, index) => {
            const positions = convertGeoJSONToLatLng(zone.geometry, zone.name);
            const isSelected = zone.name === startZone || zone.name === endZone;
            const isSearchSelected = zone.name === searchQuery;
            return (
              <Polygon
                key={`zone-${zone.name}-${index}`}
                positions={positions}
                color={getDistrictColor(zone.district_name)}
                weight={isSelected ? 3 : 1}
                fillOpacity={isSelected ? 0.6 : 0.3}
                fillColor={isSearchSelected ? "#FFFF00" : undefined}
              >
                <Popup>{zone.name}</Popup>
              </Polygon>
            );
          })}
          <PopupController zones={zones} selectedZone={startZone} type="Pickup Zone" getCentroid={getCentroid} />
          <PopupController zones={zones} selectedZone={endZone} type="Drop-off Zone" getCentroid={getCentroid} />
          {route.coordinates && route.coordinates.length > 0 && (
            <Polyline
              positions={route.coordinates.map(coord => [coord.lat, coord.lng])}
              color="#ff6f00" // Deep orange to match the theme
              weight={4}
            />
          )}
          {simulatedLocation && (
            <Marker position={simulatedLocation} icon={simulatedIcon}>
              <Popup>Current Location</Popup>
            </Marker>
          )}
          {selectedPoint && (
            <Marker position={selectedPoint} icon={doorstepIcon}>
              <Popup>Destination</Popup>
            </Marker>
          )}
          <ZoomToSelectedZone zones={zones} searchQuery={searchQuery} isJourneyActive={isJourneyActive} />
          <MapBehaviorController isJourneyActive={isJourneyActive} />
          <MapController
            simulatedLocation={simulatedLocation}
            zones={zones}
            onPointSelect={onPointSelect}
          />
        </MapContainer>
      </div>
    </ErrorBoundary>
  );
}

export default MapView;