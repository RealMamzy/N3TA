import { supabase } from "../services/supabaseClient";

function DeliveryItem({ delivery, onUpdate }) {
  const handleUpdateStatus = async (newStatus) => {
    const { error } = await supabase
      .from("deliveries")
      .update({ status: newStatus })
      .eq("id", delivery.id);
    if (error) {
      console.error("Error updating status:", error);
    } else {
      onUpdate();
    }
  };

  return (
    <li className="delivery-item">
      <div>
        <strong>Delivery {delivery.id}</strong>: {delivery.start_zone} to {delivery.end_zone}
        <br />
        Status: <span className={`status-${delivery.status}`}>{delivery.status}</span>
      </div>
      <div className="delivery-actions">
        {delivery.status === "pending" && (
          <>
            <button onClick={() => handleUpdateStatus("accepted")}>Accept</button>
            <button onClick={() => handleUpdateStatus("rejected")}>Reject</button>
          </>
        )}
        {delivery.status === "accepted" && (
          <button onClick={() => handleUpdateStatus("picked_up")}>Picked Up</button>
        )}
        {delivery.status === "picked_up" && (
          <button onClick={() => handleUpdateStatus("in_transit")}>Start Delivery</button>
        )}
        {delivery.status === "in_transit" && (
          <button onClick={() => handleUpdateStatus("delivered")}>Delivered</button>
        )}
      </div>
    </li>
  );
}

export default DeliveryItem;