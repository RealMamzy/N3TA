import React, { useState, useEffect, useRef } from "react";
import Dropdown from "./Dropdown";
import useDropdownHandlers from "../hooks/useDropdownHandlers";
import "../styles/styles.css";

function SearchBar({ searchQuery, setSearchQuery, districts, zones }) {
  const [selectedDistrict, setSelectedDistrict] = useState(null);
  const [filteredZones, setFilteredZones] = useState([]);

  const fetchDistricts = () => {
    return districts; // Already passed as a prop
  };

  const fetchZones = async (districtName) => {
    const matchingZones = zones.filter(
      (zone) => zone.district_name.toLowerCase() === districtName.toLowerCase()
    );
    console.log(`Filtered zones for ${districtName}:`, matchingZones);
    setFilteredZones(matchingZones);
    return matchingZones;
  };

  const clearZonesAndSelection = () => {
    setSelectedDistrict(null);
    setFilteredZones([]);
  };

  const { isDropdownOpen, dropdownRef, handleFocus, handleDistrictSelect, handleZoneSelect, handleInputChange } =
    useDropdownHandlers({
      setSearchQuery,
      fetchDistricts,
      fetchZones,
      setSelectedDistrict,
      clearZonesAndSelection,
    });

  // Handler for clearing the search input
  const handleClearSearch = () => {
    setSearchQuery(""); // Clear the search query
    clearZonesAndSelection(); // Reset selected district and zones
  };

  return (
    <div className="search-container" ref={dropdownRef}>
      <input
        type="text"
        className="search-input"
        placeholder="Search for a district or zone..."
        value={searchQuery}
        onChange={handleInputChange}
        onFocus={handleFocus}
      />
      {searchQuery && (
        <button className="clear-search-btn" onClick={handleClearSearch}>
          ×
        </button>
      )}
      <Dropdown
        isOpen={isDropdownOpen}
        districts={districts}
        zones={filteredZones}
        selectedDistrict={selectedDistrict}
        onDistrictSelect={handleDistrictSelect}
        onZoneSelect={handleZoneSelect}
      />
    </div>
  );
}

export default SearchBar;