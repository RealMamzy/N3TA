import DeliveryItem from "./DeliveryItem";

function DeliveryList({ deliveries, onUpdate }) {
  return (
    <ul className="delivery-list">
      {deliveries.length === 0 ? (
        <p>No deliveries assigned.</p>
      ) : (
        deliveries.map((delivery) => (
          <DeliveryItem key={delivery.id} delivery={delivery} onUpdate={onUpdate} />
        ))
      )}
    </ul>
  );
}

export default DeliveryList;