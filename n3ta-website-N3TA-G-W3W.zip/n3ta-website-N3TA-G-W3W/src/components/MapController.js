import { useEffect } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";

function MapController({ zones, onPointSelect }) {
  const map = useMap();

  useEffect(() => {
    const handleMapClick = (e) => {
      const latlng = e.latlng;
      const point = [latlng.lat, latlng.lng];

      // Find the zone that contains this point
      let selectedZone = null;
      for (const zone of zones) {
        const bounds = L.geoJSON(zone.geometry).getBounds();
        if (bounds.contains(latlng)) {
          selectedZone = zone;
          break;
        }
      }

      if (selectedZone) {
        onPointSelect(point, selectedZone);
      } else {
        alert("Please select a point within a valid zone.");
      }
    };

    map.on("click", handleMapClick);

    return () => {
      map.off("click", handleMapClick);
    };
  }, [map, zones, onPointSelect]);

  return null;
}

export default MapController;