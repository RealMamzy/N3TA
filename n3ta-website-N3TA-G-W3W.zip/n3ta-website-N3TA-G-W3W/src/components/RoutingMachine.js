import { useEffect } from "react";
import L from "leaflet";
import "leaflet-routing-machine";

const RoutingMachine = ({ start, end, isNavigating, map }) => {
  useEffect(() => {
    if (!map || !start || !end || !isNavigating) return;

    const routingControl = L.Routing.control({
      waypoints: [
        L.latLng(start[0], start[1]),
        L.latLng(end[0], end[1]),
      ],
      routeWhileDragging: false,
      lineOptions: {
        styles: [{ color: "#ffc107", weight: 4 }],
      },
      show: false,
      addWaypoints: false,
      fitSelectedRoutes: true,
      showAlternatives: false,
    }).addTo(map);

    return () => {
      try {
        if (map && routingControl) {
          map.removeControl(routingControl);
        }
      } catch (err) {
        console.error("Error removing routing control:", err);
      }
    };
  }, [start, end, isNavigating, map]);

  return null;
};

export default RoutingMachine;