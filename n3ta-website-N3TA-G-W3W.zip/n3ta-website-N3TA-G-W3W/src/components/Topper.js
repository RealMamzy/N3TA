import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import "../styles/topper.css";

/**
 * Topper component displayed on authenticated pages (like Dashboard) and auth pages (Login/SignUp).
 * Shows user status, relevant navigation links (Dashboard, Logout), or Login/SignUp links.
 */
function Topper() {
  const { user, logout, loading } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  if (loading) {
    return (
      <header className="topper">
        <nav>
          <Link to="/">
            <img src="/assets/n3ta-logo.png" alt="N3TA Logo" className="topper-logo" />
          </Link>
          <div className="nav-links">Loading...</div>
        </nav>
      </header>
    );
  }

  return (
    <header className="topper">
      <nav>
        <Link to="/">
          <img src="/assets/n3ta-logo-svg.png" alt="N3TA Logo" className="topper-logo" />
        </Link>

        <div className="nav-links">
          {user ? (
            <>
              <span>Welcome, {user.email} ({user.role || 'user'})</span>
              {user.role === 'rider' && (
                <Link to="/dashboard">Rider Dashboard</Link>
              )}
              <Link to="/">Home</Link>
              <button onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/">Home</Link>
              <Link to="/login">Login</Link>
              <Link to="/signup">Sign Up</Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}

export default Topper;