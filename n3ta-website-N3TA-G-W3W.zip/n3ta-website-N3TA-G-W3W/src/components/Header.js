import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useState } from "react";
import "../styles/header.css";

function Header({ isLoading }) {
  const { user, logout } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  const handleLogout = async () => {
    await logout();
    window.location.href = "/login";
  };

  if (isLoading) {
    return null;
  }

  return (
    <header className="header">
      <Link to="/" className="header-home">
        <img src="/assets/n3ta-logo-svg.png" alt="N3TA Logo" className="header-logo" />
      </Link>
      <div className="menu-container">
        <button onClick={toggleDropdown} className="menu-button">Menu</button>
        {isDropdownOpen && (
          <div className="dropdown-menu">
            <Link to="/dashboard" className="dropdown-item" onClick={() => setIsDropdownOpen(false)}>Rider</Link>
            <button className="dropdown-item logout-btn" onClick={() => { handleLogout(); setIsDropdownOpen(false); }}>Logout</button>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;