import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseKey = process.env.REACT_APP_SUPABASE_KEY;

// Validate environment variables
if (!supabaseUrl || !supabaseKey) {
  throw new Error(
    "Supabase URL and Key must be provided in environment variables (REACT_APP_SUPABASE_URL and REACT_APP_SUPABASE_KEY)"
  );
}

export const supabase = createClient(supabaseUrl, supabaseKey);