// import { useState } from "react";
// import Topper from "../components/Topper";
// import SearchBar from "../components/SearchBar";
// import "../styles/home.css"; 

// function Rider() {
//   const [searchTerm, setSearchTerm] = useState("");

//   const handleSearch = (term) => {
//     setSearchTerm(term);
//     // Add logic to filter deliveries if needed
//   };

//   return (
//     <>
//       <Topper />
//       <main>
//         <section className="home-section">
//           <h1>Rider Portal - N3TA</h1>
//           <img src="/assets/delivery-icon.png" alt="delivery icon" className="delivery-icon" />
//           <SearchBar onSearch={handleSearch} />
//           {searchTerm && (
//             <p>Filtering deliveries for: <strong>{searchTerm}</strong></p>
//           )}
//         </section>
//       </main>
//     </>
//   );
// }

// export default Rider;