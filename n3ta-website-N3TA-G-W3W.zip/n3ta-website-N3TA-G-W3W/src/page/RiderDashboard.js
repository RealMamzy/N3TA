import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "../contexts/AuthContext";
import Topper from "../components/Topper";
import RiderMapView from "../components/RiderMapView";
import CurrentDelivery from "../components/CurrentDelivery";
import useRiderData from "../hooks/useRiderData";
import { getCentroid, getRandomPointInZone } from "../utils/mapUtils";
import { supabase } from "../services/supabaseClient";
import "../styles/rider.css";

function RiderDashboard() {
  const { user } = useAuth();
  const {
    districts,
    zones,
    loading: zonesLoading,
    error: zonesError,
    districtDisplayNames,
    validDistricts,
    validZones,
  } = useRiderData();

  const zonesToDisplay = validZones || [];
  const districtsToDisplay = validDistricts || [];

  // --- State ---
  const [searchTerm, setSearchTerm] = useState("");
  const [currentLocation, setCurrentLocation] = useState(null);
  const [destination, setDestination] = useState(null);
  const [destinationAddressCode, setDestinationAddressCode] = useState("");
  const [deliveryStatus, setDeliveryStatus] = useState("idle");
  const [routeInfo, setRouteInfo] = useState(null);
  const [mapCenter, setMapCenter] = useState([32.8872, 13.1913]);
  const [mapZoom, setMapZoom] = useState(12);
  const mapRef = useRef(null);
  const [pastDeliveries, setPastDeliveries] = useState([]);
  const [currentDelivery, setCurrentDelivery] = useState(null);

  // --- Mock Data for Testing ---
  const mockCoordinates = {
    "TRP-00-101C-14": [32.8900, 13.2000],
    "TRP-00-101B-17": [32.8910, 13.2010],
    "TRP-01-202A-05": [32.8850, 13.1950],
    "TRP-00-101B-16": [32.8890, 13.1990], // Added to support the failing code
  };

  // --- Helper Functions for Random Data ---
  const generateRandomName = () => {
    const firstNames = ["Ahmed", "Fatima", "Omar", "Aisha", "Khalid", "Sara", "Mohammed", "Lina"];
    const lastNames = ["Salem", "Hassan", "Ali", "Nour", "Khalifa", "Zayed", "Rahim", "Mansour"];
    const randomFirst = firstNames[Math.floor(Math.random() * firstNames.length)];
    const randomLast = lastNames[Math.floor(Math.random() * lastNames.length)];
    return `${randomFirst} ${randomLast}`;
  };

  const generateRandomNote = () => {
    const notes = [
      "Leave at front door",
      "Call upon arrival",
      "Place in mailbox",
      "Deliver to neighbor if not home",
      "Ring doorbell twice",
      "Leave with security",
      "Avoid dogs in yard",
      "Use side entrance",
    ];
    return notes[Math.floor(Math.random() * notes.length)];
  };

  // --- Fetch Past Deliveries on Mount ---
  useEffect(() => {
    const fetchPastDeliveries = async () => {
      try {
        const { data, error } = await supabase
          .from("deliveries")
          .select("*")
          .eq("rider_id", user?.id)
          .in("status", ["Delivered", "Cancelled"])
          .order("completed_at", { ascending: false });
        if (error) throw error;
        setPastDeliveries(data || []);
      } catch (e) {
        console.error("Error fetching past deliveries:", e);
      }
    };
    if (user?.id) fetchPastDeliveries();
  }, [user]);

  // --- Simulate Rider Location ---
  useEffect(() => {
    if (!zonesLoading && zonesToDisplay && zonesToDisplay.length > 0 && !currentLocation) {
      try {
        const businessZone = zonesToDisplay.find(zone => zone.name === "TRP-03-102A");
        if (!businessZone) {
          console.error("Business zone TRP-03-102A not found");
          setCurrentLocation([32.8872, 13.1913]);
          return;
        }
        const startPoint = getRandomPointInZone(businessZone);
        if (startPoint && typeof startPoint[0] === "number" && typeof startPoint[1] === "number") {
          setCurrentLocation(startPoint);
          if (deliveryStatus === "idle") {
            setMapCenter(startPoint);
            setMapZoom(14);
          }
        } else {
          setCurrentLocation([32.8872, 13.1913]);
        }
      } catch (e) {
        console.error("Error simulating start location:", e);
        setCurrentLocation([32.8872, 13.1913]);
      }
    }
  }, [zonesLoading, zonesToDisplay, currentLocation, deliveryStatus]);

  // --- Event Handlers ---
  const validateN3TACode = (code) => {
    const n3taRegex = /^TRP-\d{2}-\d{3}[A-Z]-\d{2}$/;
    return n3taRegex.test(code);
  };

  const handleSearch = async () => {
    if (!searchTerm) {
      alert("Please enter an N3TA code.");
      return;
    }
    const normalizedSearchTerm = searchTerm.toUpperCase().trim();
    if (!validateN3TACode(normalizedSearchTerm)) {
      alert("Invalid N3TA code format. Please use the format TRP-XX-XXX[A-Z]-XX (e.g., TRP-00-101C-14).");
      return;
    }
    if (zonesLoading) {
      alert("Zones are still loading. Please wait.");
      return;
    }
    setDestination(null);
    setDestinationAddressCode(normalizedSearchTerm);
    setDeliveryStatus("searching");

    let foundDestinationCoords = null,
      foundZoneName = null,
      foundClientName = generateRandomName(),
      foundNote = generateRandomNote();

    // Check sessionStorage
    try {
      const savedData = sessionStorage.getItem(normalizedSearchTerm);
      if (savedData) {
        const coords = JSON.parse(savedData);
        if (Array.isArray(coords) && coords.length === 2 && typeof coords[0] === "number" && typeof coords[1] === "number") {
          foundDestinationCoords = coords;
          const parts = normalizedSearchTerm.split("-");
          if (parts.length > 1) foundZoneName = parts.slice(0, -1).join("-");
        }
      }
    } catch (e) {
      console.error(`Error reading sessionStorage for ${normalizedSearchTerm}:`, e);
    }

    // Query Supabase for any address with the N3TA code
    if (!foundDestinationCoords) {
      try {
        const { data, error } = await supabase
          .from("user_addresses")
          .select("coordinates, n3ta_code, client_name, note")
          .eq("n3ta_code", normalizedSearchTerm)
          .single();

        if (error && error.code !== "PGRST116") throw error; // Ignore "no rows" error

        if (data) {
          foundDestinationCoords = data.coordinates;
          foundZoneName = normalizedSearchTerm.split("-").slice(0, -1).join("-");
          foundClientName = data.client_name || foundClientName;
          foundNote = data.note || foundNote;
          sessionStorage.setItem(normalizedSearchTerm, JSON.stringify(foundDestinationCoords));
        }
      } catch (e) {
        console.error(`Error fetching address from Supabase for ${normalizedSearchTerm}:`, e);
      }
    }

    // Query Supabase zones table if not found in user_addresses
    if (!foundDestinationCoords) {
      try {
        const { data, error } = await supabase
          .from("zones")
          .select("geometry, name")
          .eq("name", normalizedSearchTerm.split("-").slice(0, -1).join("-"))
          .single();

        if (error && error.code !== "PGRST116") throw error;

        if (data && data.geometry) {
          const centroid = getCentroid(data.geometry); // Assuming getCentroid extracts the center of the zone
          if (centroid && Array.isArray(centroid) && centroid.length === 2) {
            foundDestinationCoords = centroid;
            foundZoneName = data.name;
            sessionStorage.setItem(normalizedSearchTerm, JSON.stringify(foundDestinationCoords));
          }
        }
      } catch (e) {
        console.error(`Error fetching zone from Supabase for ${normalizedSearchTerm}:`, e);
      }
    }

    // Fallback to mock data if still not found
    if (!foundDestinationCoords && mockCoordinates[normalizedSearchTerm]) {
      foundDestinationCoords = mockCoordinates[normalizedSearchTerm];
      foundZoneName = normalizedSearchTerm.split("-").slice(0, -1).join("-");
      sessionStorage.setItem(normalizedSearchTerm, JSON.stringify(foundDestinationCoords));
      console.log(`Using mock coordinates for ${normalizedSearchTerm}:`, foundDestinationCoords);
    }

    if (foundDestinationCoords) {
      setDestination(foundDestinationCoords);
      setDestinationAddressCode(foundZoneName || normalizedSearchTerm);
      setDeliveryStatus("assigned");
      setCurrentDelivery({
        n3taCode: normalizedSearchTerm,
        clientName: foundClientName,
        note: foundNote,
        coords: foundDestinationCoords,
        status: "Pending",
      });
      console.log("Destination found:", foundDestinationCoords, "Status:", "assigned");
    } else {
      alert(
        `Could not find location data for code: ${normalizedSearchTerm}. Please ensure the N3TA code exists in the database or use a supported code like TRP-00-101C-14, TRP-00-101B-17, or TRP-01-202A-05.`
      );
      setDeliveryStatus("error");
      setDestination(null);
      setDestinationAddressCode("");
      setCurrentDelivery(null);
      console.log("Destination not found, Status:", "error");
    }
  };

  const handleStartDelivery = () => {
    if (!currentLocation || !destination) {
      alert("Location/Destination missing.");
      return;
    }
    setDeliveryStatus("navigating");
    console.log("Starting delivery, Status:", "navigating", "From:", currentLocation, "To:", destination);
  };

  const handleConfirmDelivery = async () => {
    setDeliveryStatus("delivered");
    alert(`Delivery confirmed!`);
    const updatedDelivery = {
      ...currentDelivery,
      status: "Delivered",
      rider_id: user?.id,
      n3taCode: currentDelivery.n3taCode,
      address: currentDelivery.n3taCode,
      completed_at: new Date().toISOString(),
    };
    try {
      const { data, error } = await supabase
        .from("deliveries")
        .insert([updatedDelivery])
        .select();
      if (error) throw error;
      setPastDeliveries((prev) => [...prev, data[0]]);
    } catch (e) {
      console.error("Error saving delivery to Supabase:", e);
    }
    console.log("Delivery confirmed, Status:", "delivered");
    setTimeout(() => {
      setDestination(null);
      setDestinationAddressCode("");
      setDeliveryStatus("idle");
      setSearchTerm("");
      setRouteInfo(null);
      setCurrentDelivery(null);
      console.log("Resetting to idle, Status:", "idle");
    }, 2500);
  };

  const handleCancelDelivery = async () => {
    const cancelledDelivery = {
      ...currentDelivery,
      status: "Cancelled",
      rider_id: user?.id,
      n3taCode: currentDelivery.n3taCode,
      address: currentDelivery.n3taCode,
      completed_at: new Date().toISOString(),
    };
    try {
      const { data, error } = await supabase
        .from("deliveries")
        .insert([cancelledDelivery])
        .select();
      if (error) throw error;
      setPastDeliveries((prev) => [...prev, data[0]]);
    } catch (e) {
      console.error("Error saving cancelled delivery to Supabase:", e);
    }
    setDestination(null);
    setDestinationAddressCode("");
    setDeliveryStatus("idle");
    setSearchTerm("");
    setRouteInfo(null);
    setCurrentDelivery(null);
    alert("Delivery cancelled.");
    console.log("Delivery cancelled, Status:", "idle");
  };

  // --- Determine Map Readiness ---
  const isMapReady = !zonesLoading && !zonesError && currentLocation;
  let loadingMessage = "";
  if (zonesLoading) {
    loadingMessage = "Loading Zone Data...";
  } else if (zonesError) {
    loadingMessage = "Error loading map data!";
  } else if (!currentLocation) {
    loadingMessage = "Simulating Rider Location...";
  }

  // --- Filter Past Deliveries ---
  const filteredPastDeliveries = searchTerm
    ? pastDeliveries.filter((delivery) =>
        delivery.n3taCode.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : pastDeliveries;

  // --- Render Logic ---
  return (
    <div className="rider-dashboard-container">
      <Topper />
      <main className="rider-main-content container mx-auto px-4 py-4 md:py-6">
        {/* Controls Section */}
        <section className="rider-section rider-controls mb-4 md:mb-6">
          <h1>Rider Dashboard</h1>
          <p>Welcome, {user?.email || "Rider"}!</p>
          {(deliveryStatus === "idle" || deliveryStatus === "error") && (
            <div className="rider-search-container">
              <input
                type="text"
                className="rider-search-input"
                placeholder="Enter N3TA Delivery Code (e.g., TRP-00-101C-14)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              />
              <button
                className="rider-button search-button"
                onClick={handleSearch}
                disabled={zonesLoading || !zonesToDisplay || zonesToDisplay.length === 0}
              >
                {zonesLoading ? "Loading..." : "Find Delivery"}
              </button>
              {zonesError && (
                <p className="error-message mt-2">
                  Error loading zone data: {typeof zonesError === "string" ? zonesError : zonesError.message || "Unknown error"}
                </p>
              )}
            </div>
          )}
          {deliveryStatus === "assigned" && currentDelivery && (
            <div className="delivery-info assigned mt-4">
              <h2 className="text-xl font-semibold">New Delivery Assigned:</h2>
              <p>N3TA Code: <strong>{currentDelivery.n3taCode}</strong></p>
              <p>Client Name: <strong>{currentDelivery.clientName}</strong></p>
              <p>Note: <strong>{currentDelivery.note}</strong></p>
              <div className="action-buttons">
                <button className="rider-button start-button" onClick={handleStartDelivery}>
                  Start Delivery
                </button>
                <button className="rider-button cancel-button" onClick={handleCancelDelivery}>
                  Cancel
                </button>
              </div>
            </div>
          )}
          {deliveryStatus === "navigating" && destinationAddressCode && (
            <div className="delivery-info navigating mt-4">
              <h2 className="text-xl font-semibold">Delivering to:</h2>
              <p>N3TA Code: <strong>{destinationAddressCode}</strong></p>
              <p>Client Name: <strong>{currentDelivery.clientName}</strong></p>
              <p>Note: <strong>{currentDelivery.note}</strong></p>
              <div className="action-buttons">
                <button className="rider-button confirm-button" onClick={handleConfirmDelivery}>
                  Confirm Delivery
                </button>
                <button className="rider-button cancel-button" onClick={handleCancelDelivery}>
                  Cancel
                </button>
              </div>
            </div>
          )}
          {deliveryStatus === "delivered" && (
            <div className="delivery-info delivered mt-4">
              <h2 className="text-xl font-semibold">
                Delivery to {destinationAddressCode || "destination"} Complete!
              </h2>
              <p>Returning to idle state...</p>
            </div>
          )}
          {deliveryStatus === "error" && searchTerm && (
            <p className="error-message mt-2">
              Could not find or process N3TA code: {searchTerm}. Please try again.
            </p>
          )}
        </section>

        {/* Map Section */}
        <section className="rider-section rider-map-section flex-grow">
          <div className="rider-map-container">
            {!isMapReady ? (
              <div className="flex items-center justify-center h-full">
                <p className={`text-lg ${zonesError ? "error-message" : "text-gray-400"}`}>
                  {loadingMessage || "Initializing Map..."}
                </p>
              </div>
            ) : (
              <RiderMapView
                currentLocation={currentLocation}
                destination={destination}
                districts={districtsToDisplay}
                zones={zonesToDisplay}
                destinationAddressCode={destinationAddressCode}
                deliveryStatus={deliveryStatus}
                onDeliveryComplete={handleConfirmDelivery}
              />
            )}
          </div>
        </section>

        {/* Past Deliveries Section */}
        <section className="rider-section rider-past-deliveries mt-4">
          <h2 className="text-xl font-semibold mb-4">Past Deliveries</h2>
          {filteredPastDeliveries.length === 0 ? (
            <p>No past deliveries match your search.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="rider-deliveries-table">
                <thead>
                  <tr>
                    <th>N3TA Code</th>
                    <th>Client Name</th>
                    <th>Address</th>
                    <th>Note</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPastDeliveries.map((delivery) => (
                    <tr key={delivery.id}>
                      <td>{delivery.n3taCode}</td>
                      <td>{delivery.clientName}</td>
                      <td>{delivery.address}</td>
                      <td>{delivery.note}</td>
                      <td>{delivery.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export default RiderDashboard;