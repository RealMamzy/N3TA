import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../services/supabaseClient";
import Header from "../components/Header";
import SearchBar from "../components/SearchBar";
import MapView from "../components/MapView";
import Footer from "../components/Footer";
import useAppData from "../hooks/useAppData";
import useDelivery from "../hooks/useDelivery";
import { getRandomPointInZone, getCentroid } from "../utils/mapUtils";
import L from "leaflet";
import "leaflet-routing-machine";
import "../styles/styles.css";

function Navigtion() {
  const { user } = useAuth(); // Only use 'user' from useAuth, avoiding 'logout' here
  const navigate = useNavigate();

  const {
    districts,
    zones,
    searchQuery,
    setSearchQuery,
    loading,
    error,
    filteredDistricts,
    filteredZones,
    districtDisplayNames,
  } = useAppData();

  const {
    startZone,
    setStartZone,
    endZone,
    setEndZone,
  } = useDelivery(zones);

  const [simulatedLocation, setSimulatedLocation] = useState(null);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [route, setRoute] = useState({ coordinates: [] });
  const [isJourneyActive, setIsJourneyActive] = useState(false);
  const [journeyProgress, setJourneyProgress] = useState(0);
  const journeyIntervalRef = useRef(null);
  const [homeAddress, setHomeAddress] = useState(null);
  const [isLocationSet, setIsLocationSet] = useState(false);
  const [isAddressSaved, setIsAddressSaved] = useState(false);

  useEffect(() => {
    const savedAddress = sessionStorage.getItem('homeAddress');
    if (savedAddress) {
      setHomeAddress(savedAddress);
      setIsAddressSaved(true);
    }
  }, []);

  if (loading) {
    return (
      <div className="loading-container">
        <Header />
        <p className="loading-text">Loading districts and zones...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="loading-container">
        <Header />
        <p className="error-message">{error}</p>
      </div>
    );
  }

  const handleCurrentLocationClick = () => {
    if (zones.length === 0) return;
    const randomZoneIndex = Math.floor(Math.random() * zones.length);
    const randomZone = zones[randomZoneIndex];
    const [lat, lng] = getRandomPointInZone(randomZone);
    setSimulatedLocation([lat, lng]);
    setStartZone(randomZone);
    setIsLocationSet(true);
  };

  const handleSaveAddress = async () => {
    if (!startZone || !simulatedLocation) {
      alert("Please set your current location first.");
      return;
    }
    const zoneCode = startZone.name;
    const randomNumber = Math.floor(Math.random() * 25) + 1;
    const fullAddress = `${zoneCode}-${randomNumber}`;
    sessionStorage.setItem('homeAddress', fullAddress);
    setHomeAddress(fullAddress);
    setIsAddressSaved(true);

    if (user?.id) {
      try {
        const { data, error } = await supabase
          .from("user_addresses")
          .insert([
            {
              user_id: user.id,
              n3ta_code: fullAddress,
              coordinates: simulatedLocation,
              client_name: user.email || "Anonymous User",
              note: "N/A",
            },
          ])
          .select();
        if (error) throw error;
        console.log("Address saved to Supabase:", data);
      } catch (error) {
        console.error("Error saving home address to Supabase:", error);
        alert("Failed to save address to database.");
      }
    }
  };

  const onPointSelect = (point, zone) => {
    setSelectedPoint(point);
    setEndZone(zone);
  };

  const stopJourney = () => {
    if (journeyIntervalRef.current) {
      clearInterval(journeyIntervalRef.current);
      journeyIntervalRef.current = null;
    }
    setIsJourneyActive(false);
    setJourneyProgress(0);
    setRoute({ coordinates: [] });
    alert("Journey stopped!");
  };

  const handleStartJourney = () => {
    if (!simulatedLocation || !searchQuery) {
      alert("Please set your current location and select a zone.");
      return;
    }

    const selectedZoneData = zones.find((zone) => zone.name === searchQuery);
    if (!selectedZoneData) {
      alert("Selected zone not found.");
      return;
    }

    const destination = selectedPoint || getCentroid(selectedZoneData.geometry);

    const router = L.Routing.osrmv1();
    router.route(
      [
        L.Routing.waypoint(L.latLng(simulatedLocation[0], simulatedLocation[1])),
        L.Routing.waypoint(L.latLng(destination[0], destination[1])),
      ],
      (err, routes) => {
        if (err) {
          alert("Error generating route: " + err.message);
          return;
        }

        if (routes && routes.length > 0) {
          const routeCoordinates = routes[0].coordinates.map(coord => ({
            lat: coord.lat,
            lng: coord.lng,
          }));
          setRoute({ coordinates: routeCoordinates });

          setSimulatedLocation([routeCoordinates[0].lat, routeCoordinates[0].lng]);

          setIsJourneyActive(true);
          setJourneyProgress(0);

          let currentStep = 0;
          const totalSteps = routeCoordinates.length - 1;

          const interval = setInterval(() => {
            currentStep++;
            const progress = currentStep / totalSteps;
            setJourneyProgress(progress);

            const routeIndex = Math.min(Math.floor(progress * (routeCoordinates.length - 1)), routeCoordinates.length - 1);
            const coord = routeCoordinates[routeIndex];
            if (coord) {
              setSimulatedLocation([coord.lat, coord.lng]);
            }

            if (currentStep >= totalSteps) {
              clearInterval(interval);
              journeyIntervalRef.current = null;
              setIsJourneyActive(false);
              alert("Journey completed!");
            }
          }, 300);

          journeyIntervalRef.current = interval;
        } else {
          alert("No route found between the start and destination.");
        }
      }
    );
  };

  return (
    <div className="app-container">
      <Header />
      <main>
        <section className="search-section">
          <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            districts={districts}
            zones={zones}
          />
        </section>
        <section className="n3ta-code-section">
          <div className="journey-buttons">
            {isLocationSet && !isAddressSaved && (
              <button
                onClick={handleSaveAddress}
                className="action-button save-address-btn"
              >
                Save my address
              </button>
            )}
            {searchQuery && (
              <button
                onClick={handleStartJourney}
                className="action-button start-journey-btn"
                disabled={isJourneyActive}
              >
                {isJourneyActive ? `Journey in Progress (${(journeyProgress * 100).toFixed(0)}%)` : "Start Journey"}
              </button>
            )}
            {isJourneyActive && (
              <button
                onClick={stopJourney}
                className="action-button stop-journey-btn"
              >
                Stop Journey
              </button>
            )}
          </div>
        </section>
        <div className="map-wrapper">
          <MapView
            districts={filteredDistricts}
            zones={filteredZones}
            startZone={startZone}
            endZone={endZone}
            route={route}
            districtDisplayNames={districtDisplayNames}
            searchQuery={searchQuery}
            simulatedLocation={simulatedLocation}
            selectedPoint={selectedPoint}
            onPointSelect={onPointSelect}
            isJourneyActive={isJourneyActive}
          />
          <section className="navigation-controls">
            <button onClick={handleCurrentLocationClick} className="current-location-btn" />
          </section>
        </div>
        {isAddressSaved && homeAddress && (
          <section className="home-address-section">
            <h2>Home Address</h2>
            <p>{homeAddress}</p>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}

export default Navigtion;