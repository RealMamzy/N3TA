import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import Topper from "../components/Topper";
import "../styles/home.css";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/dashboard";

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      await signIn(email, password);
      navigate(from, { replace: true });
    } catch (error) {
      setError("Login failed: " + error.message);
    }
  };

  return (
    <>
      <Topper />
      <main>
        <section className="auth-section">
          <h2>Login to N3TA</h2>
          {error && <p className="error-message">{error}</p>}
          <form onSubmit={handleSubmit} className="auth-form">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="auth-input"
              required
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="auth-input"
              required
            />
            <button type="submit" className="auth-button">Login</button>
          </form>
        </section>
      </main>
    </>
  );
}

export default Login;