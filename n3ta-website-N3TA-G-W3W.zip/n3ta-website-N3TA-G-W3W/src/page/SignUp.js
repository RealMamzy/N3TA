import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import Topper from "../components/Topper";
import "../styles/home.css";

function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      await signUp(email, password);
      navigate("/dashboard");
    } catch (error) {
      setError("Sign up failed: " + error.message);
    }
  };

  return (
    <>
      <Topper />
      <main>
        <section className="auth-section">
          <h2>Sign Up for N3TA</h2>
          {error && <p className="error-message">{error}</p>}
          <form onSubmit={handleSubmit} className="auth-form">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="auth-input"
              required
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="auth-input"
              required
            />
            <button type="submit" className="auth-button">Sign Up</button>
          </form>
        </section>
      </main>
    </>
  );
}

export default SignUp;